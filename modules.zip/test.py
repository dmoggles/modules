


name = 'fred'
host = 'aetolia.com'
port = 23
encoding = 'ascii'
executable_path = r'c:\python27\Python.exe c:\dev\modules\runnable.py'
#print(executable_path)
#print(os.path.exists(executable_path))

